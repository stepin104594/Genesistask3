#include<stdio.h>

int addition(int a) {
    return a+4;
}

# trailgen

[![Codacy Badge](https://api.codacy.com/project/badge/Grade/c50134ca34f14b879de4ecfbd913c200)](https://app.codacy.com/manual/krishnalalasa.k/trailgen?utm_source=github.com&utm_medium=referral&utm_content=stepin104594/trailgen&utm_campaign=Badge_Grade_Dashboard)
![C/C++ CI](https://github.com/stepin104594/trailgen/workflows/C/C++%20CI/badge.svg)
![cppcheck-action](https://github.com/stepin104594/trailgen/workflows/cppcheck-action/badge.svg)


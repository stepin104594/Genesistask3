#ifndef FUNC_H_INCLUDED
#define FUNC_H_INCLUDED
int addition(int a);
#endif // FUNC_H_INCLUDED

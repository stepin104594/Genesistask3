#include<stdio.h>
#include"func.h"

int main() {
    int x =2;

    x=addition(x);
    printf("number is: %d\n",x);
}
